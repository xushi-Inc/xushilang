def out(a):
    print(a)
def inter(a):
    b=input(a)
    return b
def d_fc(a,b,c):
    exec(f"def {a}({b}):\n    "+c.replace("\n","\n    "),globals())
def d_va(a,b):
    exec(f"{a}={b}",globals())
def d_cs(a,b):
    exec(f"class {a}:\n    "+b.replace("\n","\n    "),globals())
def long(a):
    return len(a)
def WriteFile(a,b,c,d):
    if b=="a" or b=="w" or b=="wb":
        with open(a,b,encoding=c) as f:
            f.write(d)
    else:
        print("你的写入方法不对")
def ipt(a):
    r1=""
    with open(a,"r",encoding="utf-8") as r:
        r1=r.read()
    exec(r1,globals()) 
def r_file(a,b):
    r1=""
    with open(a,"r",encoding=b) as r:
        r1=r.read()
    return r1
class A1:
    def __str__(a):
        return len(a)-1       
def do_while(a,b):
    exec(f"while {a}:\n    "+b.replace("\n","\n    "),globals())
def loop(a,b):
    exec(f"for {a.replace('to','in')}:\n    "+b.replace("\n","\n    "),globals())
def if_elif_else(a,b,c,d):
    e=f"if {a}:\n    "+b.replace("\n","\n    ")+"\n"
    f=0-1
    for xx in c:
        f+=1
        e+=f"elif {c[f].split('::::')[0]}:\n    "+c[f].split('::::')[1].replace("\n","\n    ")+"\n"
    e+=f"else:\n    "+d.replace("\n","\n    ")
    exec(e,globals())
def if_else(a,b,c):
    d=f"if {a}:\n    "+b.replace("\n","\n    ")+"\nelse:\n    "+c.replace("\n","\n    ")
    exec(d,globals())
def __if__(a,b):
    c=f"if {a}:\n    "+b.replace("\n","\n    ")
    exec(c,globals())